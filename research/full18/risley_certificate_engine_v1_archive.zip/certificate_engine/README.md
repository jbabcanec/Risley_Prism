# Bounded full-vector certificate engine

This is an executable, standard-library Python certificate evaluator for the exact coupled-vector three-prism model. It is a bounded implementation step, **not a complete inverse, a parameter fit or an all-eighteen accuracy certificate**. The published research report remains unchanged.

## Run

Requires Python 3.10 or newer; no third-party package is used. This workspace was checked with the already installed Ubuntu WSL Python 3.12.3. No software was installed.

From this folder on Linux/WSL:

    python3 engine.py certify spotcheck/small_box_input.json certificate.json
    python3 engine.py verify spotcheck/small_box_input.json spotcheck/small_box_certificate.json
    python3 verify_spotcheck.py

On this connected Windows computer, use the existing WSL interpreter:

    wsl.exe -d Ubuntu -- python3 /mnt/c/Users/josep/Documents/Codex/2026-10-02/task/full18_research/certificate_engine/engine.py verify /mnt/c/Users/josep/Documents/Codex/2026-10-02/task/full18_research/certificate_engine/spotcheck/small_box_input.json /mnt/c/Users/josep/Documents/Codex/2026-10-02/task/full18_research/certificate_engine/spotcheck/small_box_certificate.json

`spotcheck.py` regenerates the one labeled synthetic fixture and its deterministic validation cases. It performs no sampling campaign or inverse search. The supplied record and certificates allow verification without generating another record. Python may create ordinary local bytecode caches; these are not part of the deliverable or proof evidence.

## Exact input contract

The input has exactly eighteen chart-coordinate intervals under `box`:

| Coordinates | Meaning |
|---|---|
| `r1,r2,r3` | Signed wedge slopes, \(r_j=\tan a_j\), with native wedges in ±18 degrees. |
| `p1,p2,p3` | Initial-phase charts, \(p_j=\tan(\phi_j/2)\), with phases in ±18 degrees. |
| `v1,v2,v3` | Speed charts, \(v_j=\tan(\pi N_j/20)\), with signed speeds in ±3.5 Hz. |
| `n1,n2,n3` | Separate native indices in [1.3,1.8]. |
| `tx,ty` | Incident slopes, \(\tan\beta_x,\tan\beta_y\), with angles in ±25 degrees. |
| `bx,by,g,d` | Shared source offsets in [-5,5], repeated gap in [2,15], screen distance in [50,200]. Units are the model's native length units. |

Each interval is a two-element array of exact rational strings or integers. Strings such as `"1/3"` or `"0.05"` denote exact rationals. JSON floating-point numbers and booleans are rejected as endpoints, observations or allowances. The engine uses the original index chart, not the reduced h/c chart.

The model identifier must be `coupled_vector_snell_three_prism`. A provenance description is required. Known canonical/independent-axis labels are rejected, but a label does not independently authenticate a record's origin. No saved canonical record was used.

The sampling object must be exactly `{"count":200,"step":"1/20","start":"0"}`. Optional timestamps must each equal exact \(k/20\), \(k=0,\ldots,199\). The engine never uses a binary64 arange clock. Optional observations contain exactly 200 rational [x,y] pairs and a nonnegative rational `epsilon`, shared by all 400 scalar observations. Without observations, the request is a forward/physical-domain box check.

`bits` selects a dyadic grid, default 80 and allowed range 32–256. This is an arithmetic grid setting, not a promised number of correct digits in a broad-box result.

## What is implemented

The incoming unit transverse direction is \(t/\sqrt{1+|t|^2}\), and the first entrance position is \(b+6t\). Rotor phases on the exact clock use rational complex rotations from the half-angle charts and integer powers. No floating-point trigonometric function is used.

Every prism propagates the coupled two-component direction through the audited H/P/radicand/R/Z formulas and the selected nonnegative exit root. Position and traversal quantities are carried as **five interval coefficients in the shared order [bx,by,g,d,constant]**. Optical coefficients remain interval enclosures. The recurrence is affine in the same four geometry variables at every stage/sample; it never chooses independently fitted geometries per row.

Evaluating each affine form over the entire geometry rectangle bounds every parameter choice. This implements complete geometry enclosure, not joint affine feasibility or the joint-violation LP. Interval dependence can make it conservative.

The native angular prior endpoints are enclosed rigorously using Machin's formula for pi, alternating rational arctangent sums and Taylor remainders for sin/cos. A box must be proved wholly inside the original prior to receive a whole-box retention certificate. A box merely intersecting an uncertain irrational prior boundary remains unresolved unless another valid exclusion applies.

The data-only final-prism test uses all observations to certify
\[
R_3(k)/Z_3(k)\ge
\max\{0,(50-\overline M_k)/53\},
\]
where \(\overline M_k\) is a rigorously rounded upper bound for
\(\tan18^\circ\sqrt{(|y_{kx}|+\epsilon)^2+(|y_{ky}|+\epsilon)^2}\).
It is conditional on original-prior compatibility and **does not establish feasibility**. It does not substitute a fitted optical point for the prior.

## Outcome and certificate semantics

- **excluded:** the certificate names a proven contradiction covering every potentially physical point in the supplied box: a disjoint original prior, a nonpositive upper bound on a required strict physical guard, or an output enclosure disjoint from an observation band.
- **retained:** every point of the supplied box is inside the original prior and strictly physical at all 200 samples. If observations are present, every output enclosure is inside its band, so the entire box is compatible. This is much stronger than interval overlap, but is local to the supplied box and proves no global recovery.
- **unresolved:** the complete input box remains in consideration. The engine cannot yet establish a uniform sign, safe denominator or whole-box compatibility. It neither discards the box nor declares it feasible.

If a radicand enclosure straddles zero, the evaluator may bound its nonnegative-root portion while marking physical status unresolved. Subsequent outputs then enclose the potentially physical subset; no real forward value is asserted for negative-radicand inputs. A divisor containing zero stops evaluation as unresolved. Early exits retain their sample/stage and exact rational witness.

Certificates contain input/source hashes, prior enclosures, exact sample times, guard intervals, all processed traversal affine coefficients, screen affine coefficients and output intervals. Deterministic `verify` recomputes and compares the whole certificate, rejecting tampered evidence. This replay uses the same evaluator; independent source and alternate-formula checks are recorded separately. Source changes require fresh certificates.

## Rounding guarantees

All primitive arithmetic uses exact Python integers and Fractions followed by directed floor/ceiling onto multiples of \(2^{-\text{bits}}\). Multiplication and division check all endpoint combinations; division through zero raises. Squaring handles zero-crossing intervals explicitly. Square-root endpoints use integer square-root comparisons and exact rational inequalities. Each rounded endpoint is outward; composed enclosures can be much wider than one grid unit.

The interval kernel contains no floating-point arithmetic. Floating wall-time measurements and any displayed decimal summaries are informational only; all certificate comparisons use exact rationals. Rigorous enclosures do not guarantee useful widths on large optical boxes.

## The single validation record

The supplied [synthetic record](spotcheck/synthetic_fullvector_record.json) is generated from one explicitly stated rational full-vector chart point with nonzero signed wedges, phases, speeds, two incident slopes and source offsets. It contains exactly 200 pairs on \(k/20\). Its rational observations are midpoints of proved point-forward enclosures, with their outward error recorded.

A box of halfwidth \(10^{-8}\) in **all eighteen chart coordinates** is supplied around that point. Its validation allowance is derived from the entire forward enclosure, not inferred as a real sensor noise bound. The box is deliberately supplied for this implementation check; it was not recovered from data.

The same single record is used for four fixed checks:

| Supplied box | Checked outcome |
|---|---|
| Small all18 box | Retained: all 200 physical traces and 400 bands certified. |
| Same local optics with distant screen geometry | Excluded by the x observation band at sample 0. |
| Full-prior outer box | Unresolved at an axial divisor enclosure; retained for future refinement. |
| Specified nontransmitting optical box | Excluded by a strictly negative exit-radicand upper bound at sample 0. |

[results.json](spotcheck/results.json) records exact bounds and witnesses. The point-forward maximum coordinate width is \(3243/604462909807314587353088\), about \(5.37\times10^{-21}\). The synthetic whole-box allowance is \(33070397787796324767/2417851639229258349412352\), about \(1.37\times10^{-5}\) in screen units. These values describe one proof check, not a benchmark or recovery threshold.

Independent validation uses a separate normalized three-dimensional vector-Snell and ray/plane implementation at higher precision, with exact rational point rotors. It checks all 400 reference outputs against the engine point enclosures and the record's stated bounds. The [independent review](independent_review.md) and [machine-readable results](independent_review.json) report a pass: all 400 alternate-formula outputs are contained, 1,600 shared-geometry affine ranges and 200 final-prism margin bounds check, and 515 exact kernel checks pass. Certificate replay and tamper rejection also pass. No hardware or actual-record success is claimed.

## Remaining implementation gap

The engine does not yet solve the shared four-variable joint-violation LP, replay sparse mixed-strict circuit witnesses, subdivide a complete optical cover, certify continuation/discriminants, compute sixteen-variable envelopes, or invoke an exhaustive algebraic fallback. Its full-prior unresolved result is the concrete current bottleneck: interval dependence and uncertain signs need subdivision and sharper validated bounds, followed by complete leaf bookkeeping. A qualifying full-vector record with units and an error contract is still required for real-data validation.

The audited theoretical basis is [full-vector optics](../theory/physical_vector_inverse.md), [boundary/guard formulas](../theory/global_boundary_compactification.md), [data-dependent margin](../theory/data_dependent_critical_margin.md) and [adaptive interface](../theory/certified_adaptive_inverse_algorithm.md). The existing nineteen Lean results support some identities and the margin implication; they do not formally verify this Python engine.
